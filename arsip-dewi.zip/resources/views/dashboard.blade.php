@extends('layouts.template_inspi')
@section('page-title', 'Dashboard')
@section('custom_css')

@endsection
@section('content')



                
@endsection

@section('custom_js')

@endsection
