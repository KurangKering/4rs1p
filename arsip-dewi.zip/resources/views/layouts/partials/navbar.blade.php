
                 <!-- add class "multiple-expanded" to allow multiple submenus to open -->
                 <!-- class "auto-inherit-active-class" will automatically add "active" class for parent elements who are marked already with class "active" -->
                 <li class="has-sub">
                    <a href="index.html">
                        <i class="entypo-gauge"></i>
                        <span class="title">Dashboard</span>
                    </a>
                    <ul>
                        <li>
                            <a href="index.html">
                                <span class="title">Dashboard 1</span>
                            </a>
                        </li>
                        <li>
                            <a href="dashboard-2.html">
                                <span class="title">Dashboard 2</span>
                            </a>
                        </li>
                        <li>
                            <a href="dashboard-3.html">
                                <span class="title">Dashboard 3</span>
                            </a>
                        </li>
                        
                    </ul>
                </li>
              