<?php $__env->startSection('page-title', 'Pengguna'); ?>
<?php $__env->startSection('custom_css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-sm-12">
    <div class="ibox float-e-margins">
      <div class="ibox-title">
        <div class="ibox-tools">
          <button class="btn btn-success" onclick="location.href='<?php echo e(route('users.create')); ?>'">Tambah Pengguna</button>
          
        </div>
      </div>
      <div class="ibox-content">
        <div class="table-responsive">
          <table id="tbl-user"  class="table table-striped">
            <thead>
             <tr>
               <th>Nama</th>
               <th>Username</th>
               <th>Email</th>
               <th>Hak Akses</th>
               <th>Status</th>
               <th>Action</th>
             </tr>
           </thead>
           <tbody>
             <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
             <tr>
              <td><?php echo e($user->name); ?></td>
              <td><?php echo e($user->username); ?></td>
              <td><?php echo e($user->email); ?></td>
              <td>
                <?php if(!empty($user->getRoleNames())): ?>
                <?php $__currentLoopData = $user->getRoleNames(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php echo e($v); ?>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </td>
              <td>
                <?php echo e(Config::get('enums.status_user')[$user->status]); ?>

              </td>
              <td style="white-space: nowrap; width: 1%">
                <?php if(Auth::check()): ?>
                <a class="btn btn-primary" href="<?php echo e(route('users.edit',$user->id)); ?>">Edit</a>
                <?php if(! (Auth::user()->id == $user->id)): ?>
                <?php echo Form::open(['method' => 'DELETE','route' => ['users.destroy', $user->id],'style'=>'display:inline']); ?>

                <?php echo Form::submit('Delete', ['class' => 'btn btn-danger']); ?>

                <?php echo Form::close(); ?>

                <?php endif; ?>
                <?php endif; ?>

              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div> <!-- end col -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<script>
  let $table= $("#tbl-user").DataTable();

  $('form').on('click', 'input[type="submit"]', function(e) {
    e.preventDefault();

    swal({
      icon : 'warning',
      title : 'Hapus User!',
      text : 'yakin ingin menghapus user ini ?',
      buttons : {
        'Batal' : {
          className : 'btn btn-inverse'
        },
        'Hapus' : {
          className : 'btn btn-danger'
        },
      },
      closeOnClickOutside : false
    })
    .then(clicked => {
      if (clicked == 'Hapus') {
        $(this).parent().submit();
      }

    })

    ;
    
  });
  
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template_inspi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>