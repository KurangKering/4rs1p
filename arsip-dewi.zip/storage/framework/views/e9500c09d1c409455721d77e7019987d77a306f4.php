
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title><?php echo $__env->yieldContent('title','Arsip'); ?></title>

    <link href="<?php echo e(asset('templates/inspinia_271/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('templates/inspinia_271/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('templates/inspinia_271/css/plugins/dataTables/datatables.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('templates/inspinia_271/css/plugins/jasny/jasny-bootstrap.min.css')); ?>" rel="stylesheet">



    <link href="<?php echo e(asset('templates/inspinia_271/css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('templates/inspinia_271/css/style.css')); ?>" rel="stylesheet">
    <?php echo $__env->yieldContent('custom_css'); ?>

</head>

<body>

    <div id="wrapper">

        <?php echo $__env->make('layouts.partials.navbar_inspi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

        <div id="page-wrapper" class="gray-bg">
            <div class="row border-bottom">
                <nav class="navbar navbar-static-top" role="navigation" style="margin-bottom: 0">
                    <div class="navbar-header">
                        <a class="navbar-minimalize minimalize-styl-2 btn btn-primary " href="<?php echo e(asset('templates/inspinia_271/#')); ?>"><i class="fa fa-bars"></i> </a>

                    </div>
                    <ul class="nav navbar-top-links navbar-right">
                        

                        <li>
                            <a href="<?php echo e(route('logout')); ?>"
                            onclick="event.preventDefault();
                            document.getElementById('logout-form').submit();">
                            <i class="fa fa-sign-out"></i> Log out
                        </a>
                        <form id="logout-form" action="<?php echo e(route('logout')); ?>" method="POST" style="display: none;">
                            <?php echo csrf_field(); ?>
                        </form>
                    </li>

                    
                </ul>

            </nav>
        </div>
        <div class="row wrapper border-bottom white-bg page-heading">
            <div class="col-lg-10">
                <h2><?php echo $__env->yieldContent('page-title','page-title'); ?></h2>

            </div>
            <div class="col-lg-2">

            </div>
        </div>


        <div class="wrapper wrapper-content animated fadeInRight">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
        <div class="footer" >
            <div class="pull-right">
                10GB of <strong>250GB</strong> Free.
            </div>
            <div>
                <strong>Copyright</strong> Example Company &copy; 2014-2017
            </div>
        </div>

    </div>
</div>



<!-- Mainly scripts -->
<script src="<?php echo e(asset('templates/inspinia_271/js/jquery-3.1.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('templates/inspinia_271/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('templates/inspinia_271/js/plugins/metisMenu/jquery.metisMenu.js')); ?>"></script>
<script src="<?php echo e(asset('templates/inspinia_271/js/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('templates/inspinia_271/js/plugins/dataTables/datatables.min.js')); ?>"></script>
<script src="<?php echo e(asset('templates/inspinia_271/js/plugins/pdfjs/pdf.js')); ?>"></script>
<script src="<?php echo e(asset('templates/inspinia_271/js/plugins/jasny/jasny-bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/sweetalert/dist/sweetalert.min.js')); ?>"></script>
<script src="<?php echo e(asset('plugins/axios/dist/axios.min.js')); ?>"></script>




<!-- Custom and plugin javascript -->
<script src="<?php echo e(asset('templates/inspinia_271/js/inspinia.js')); ?>"></script>
<script src="<?php echo e(asset('templates/inspinia_271/js/plugins/pace/pace.min.js')); ?>"></script>

<script src="<?php echo e(asset('templates/inspinia_271/js/plugins/slimscroll/jquery.slimscroll.min.js')); ?>"></script>

<?php echo $__env->yieldContent('custom_js'); ?>

</body>

</html>
