<nav class="navbar-default navbar-static-side" role="navigation">
    <div class="sidebar-collapse">
        <ul class="nav metismenu" id="side-menu">
            <li class="nav-header">
                <div class="dropdown profile-element"> <span>
                    <img alt="image" class="img-circle" src="<?php echo e(asset('images/default-picture-small.png')); ?>" />
                </span>
                <a data-toggle="dropdown" class="dropdown-toggle" href="<?php echo e(asset('templates/inspinia_271/#')); ?>">
                    <span class="clear"> <span class="block m-t-xs"> <strong class="font-bold"><?php echo e(Auth::user()->name); ?></strong>
                    </span> <span class="text-muted text-xs block"><?php echo e(implode(Auth::user()->getRoleNames()->toArray())); ?> <b class="caret"></b></span> </span> </a>
                    <ul class="dropdown-menu animated fadeInRight m-t-xs">
                        <li><a href="<?php echo e(url('profile')); ?>">Profile</a></li>
                    </ul>
                </div>
                <div class="logo-element">
                    +
                </div>
            </li>
            

            <?php if(Auth::check()): ?>
            <li>
                <a href="<?php echo e(url('/')); ?>"><i class="fa fa-circle-thin"></i> <span class="nav-label">Dashboard</span></a>
            </li>

            <?php if(auth()->check() && auth()->user()->hasRole("Panitera")): ?>
            <li>
                <a href="<?php echo e(route('berkas_perkara.index')); ?>"><i class="fa fa-circle-thin"></i> <span class="nav-label">Berkas Perkara</span></a>
            </li>
            <?php elseif(auth()->check() && auth()->user()->hasRole("Panitera Muda")): ?>
            <li>
                <a href="<?php echo e(route('users.index')); ?>"><i class="fa fa-circle-thin"></i> <span class="nav-label">Pengguna</span></a>
            </li>



            <li>
                <a href="<?php echo e(route('jenis_perkara.index')); ?>"><i class="fa fa-circle-thin"></i> <span class="nav-label">Jenis Perkara</span></a>
            </li>
            <li>
                <a href="<?php echo e(route('perkara.index')); ?>"><i class="fa fa-circle-thin"></i> <span class="nav-label">Perkara</span></a>
            </li>
            
            <li>
                <a href="<?php echo e(route('riwayat_pembaca.index')); ?>"><i class="fa fa-circle-thin"></i> <span class="nav-label">Riwayat Pembaca</span></a>
            </li>
            <?php endif; ?>
            <?php endif; ?>
        </ul>

    </div>
</nav>