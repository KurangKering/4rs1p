
<!DOCTYPE html>
<html>

<head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Arsip</title>

    <link href="<?php echo e(asset('templates/inspinia_271/css/bootstrap.min.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('templates/inspinia_271/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('templates/inspinia_271/css/plugins/iCheck/custom.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('templates/inspinia_271/css/animate.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('templates/inspinia_271/css/style.css')); ?>" rel="stylesheet">

    <style>
    .loginscreen.middle-box {
     width: 400px; 
 }
</style>
</head>

<body class="gray-bg">

    <div class="middle-box text-center loginscreen   animated fadeInDown">
        <div>
            <div>


            </div>

            <h3>Form Pendaftaran Akun</h3>
            <div id="error-message">

            </div>

            <form class="m-t" method="POST" action="<?php echo e(route('daftar_store')); ?>" aria-label="<?php echo e(__('Register')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <input type="text" class="form-control " placeholder="Nama" name="name" id="name" value="<?php echo e(old('name')); ?>"  autofocus >
                </div>
                <div class="form-group">
                    <input type="text" class="form-control" placeholder="Username" name="username" id="username" value="<?php echo e(old('username')); ?>" >
                </div>
                <div class="form-group">
                    <input type="email" class="form-control" placeholder="Email" name="email" id="email" value="<?php echo e(old('email')); ?>" >
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" placeholder="Password" name="password" id="password" >
                </div>
                <div class="form-group">
                    <input id="confirm-password" placeholder="Confirm Password" type="password" class="form-control" name="confirm-password" >
                </div>

                <button type="submit" class="btn btn-primary block full-width m-b">Daftar</button>

                <p class="text-muted text-center"><small>Sudah Punya Akun?</small></p>
                <a class="btn btn-sm btn-white btn-block" href="<?php echo e(route('login')); ?>">Login</a>
            </form>
        </div>
    </div>

    <!-- Mainly scripts -->
    <script src="<?php echo e(asset('templates/inspinia_271/js/jquery-3.1.1.min.js')); ?>"></script>
    <script src="<?php echo e(asset('templates/inspinia_271/js/bootstrap.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/axios/dist/axios.min.js')); ?>"></script>
    <script src="<?php echo e(asset('plugins/sweetalert/dist/sweetalert.min.js')); ?>"></script>
    <!-- iCheck -->
    <script src="<?php echo e(asset('templates/inspinia_271/js/plugins/iCheck/icheck.min.js')); ?>"></script>
    <script>
        $(document).ready(function(){
            $('.i-checks').iCheck({
                checkboxClass: 'icheckbox_square-green',
                radioClass: 'iradio_square-green',
            });
        });

        $("form").submit(function(event) {
            $('#error-message').html("");

            $("button[type='submit']").attr('disabled', true);
            event.preventDefault();
            $("input").parent().removeClass('has-error');
            let formData = $(this).serialize();
            axios.post($(this).attr('action'), formData )
            .then(res => {
                swal({
                    icon : 'success',
                    title : 'Berhasil Daftar',
                    text : 'Silahkan Tunggu Konfirmasi Admin',
                    buttons : false,
                    closeOnClickOutside : false,
                    timer : 2000
                })
                .then(btn => {
                    location.href='<?php echo e(route('login')); ?>';
                });
                $("button[type='submit']").attr('disabled', false);

            })
            .catch(err => {
                let list= '';
                $.each(err.response.data.errors, function(index, val) {
                    $.each(val, function(index2, val2) {
                        console.log(val2);
                        list += "<p>" + val2 + "</p>";
                    });
                });
                $("#error-message").html(
                 "<div class=\"alert alert-danger\">\
                 "+list+"\
                 </div>\
                 ");
                $("button[type='submit']").attr('disabled', false);

            });
        });
    </script>
</body>

</html>
