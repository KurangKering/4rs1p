<?php $__env->startSection('page-title', 'Ubah Jenis Perkara'); ?>
<?php $__env->startSection('custom_css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-sm-6 col-sm-offset-3">
       <?php if(count($errors) > 0): ?>

      <div class="alert alert-danger">

        <strong>Ooops!</strong> Ada Kesalahan.<br><br>

        <ul>

         <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

         <li><?php echo e($error); ?></li>

         <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

       </ul>

     </div>

     <?php endif; ?>
    <div class="ibox float-e-margins">

      <div class="ibox-title">
        <h3>Form Ubah Jenis Perkara</h3>
      </div>
    

     <div class="ibox-content">
      <form action="<?php echo e(route('jenis_perkara.update', $jenis->id)); ?>" class="form" method="POST">
        <?php echo csrf_field(); ?>
        <?php echo e(method_field('PATCH')); ?>


        <div class="form-group">
          <label for="" class="control-label">ID</label>
          <input type="text" class="form-control" readonly value="<?php echo e($jenis->id); ?>">
        </div>
        <div class="form-group">
          <label for="" class="control-label">Nama</label>
          <input type="text" class="form-control" name="nama" value="<?php echo e($jenis->nama); ?>">
        </div>
        <div class="form-group text-center">
          <button type="submit" class="btn btn-primary">Submit</button>
        </div>
      </form>
    </div>
  </div>
</div> <!-- end col -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<script>
  let $tableJenis = $("#table-jenis").DataTable();
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template_inspi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>