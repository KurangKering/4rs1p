<?php $__env->startSection('page-title', 'Daftar Perkara'); ?>
<?php $__env->startSection('custom_css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-sm-12">
    <div class="ibox float-e-margins">
      <div class="ibox-title">
        <div class="ibox-tools">
          <button class="btn btn-success" onclick="location.href='<?php echo e(route('perkara.create')); ?>'">Tambah Perkara</button>
        </div>
      </div>
      <div class="ibox-content">
        <div class="table-responsive">
          <table class="table" id="table-perkara">
            <thead>
              <tr>
                <th>No </th>
                <th>No Perkara</th>
                <th>Jenis Perkara</th>
                <th>Jumlah Berkas</th>
                <th width="1%">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $no = 1; ?>
              <?php $__currentLoopData = $perkaras; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $perkara): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
               <td><?php echo e($no++); ?></td>
               <td><?php echo e($perkara->no_perkara); ?></td>
               <td><?php echo e($perkara->jenis_perkara->nama); ?></td>
               <td><?php echo e(count($perkara->berkas_perkara)); ?></td>
               <td style="white-space: nowrap">

                <a href="<?php echo e(route('perkara.edit', $perkara->id)); ?>" class="btn btn-primary">Edit</a>
                <a onclick="deletePerkara('<?php echo e($perkara->id); ?>')" class="btn btn-danger">Delete</a>

              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div> <!-- end col -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<script>
  let $tablePerkara = $("#table-perkara").DataTable();


  function deletePerkara(id) {
    swal({
      icon : 'warning',
      title : 'Hapus  Perkara ? ',
      text : 'Yakin Hapus Perkara ? ',
      buttons : {
        'Batal' : {
          className : 'btn btn-info'
        },
        'Hapus' : {
          className : 'btn btn-danger'

        }
      },
      closeOnClickOutside : false,
    })
    .then(btn => {
      if (btn == 'Hapus') {
       axios.post('<?php echo e(route('perkara.index')); ?>'+ '/' + id, {

        _method : 'DELETE',
        _token : '<?php echo e(csrf_token()); ?>',

      })
       .then(resp => {
        location.href = '<?php echo e(route('perkara.index')); ?>';
      })
     }

   });
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template_inspi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>