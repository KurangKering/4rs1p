<?php $__env->startSection('page-title', 'Ubah Pengguna'); ?>
<?php $__env->startSection('custom_css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="ibox float-e-margins">

  <?php if(count($errors) > 0): ?>
  
  <div class="alert alert-danger">

    <strong>Ooops!</strong> Ada Kesalahan.<br><br>

    <ul>

     <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

     <li><?php echo e($error); ?></li>

     <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

   </ul>

 </div>

 <?php endif; ?>
 <div class="ibox-content">


   <?php echo Form::model($user, ['method' => 'PATCH','route' => ['users.update', $user->id]]); ?>


   <div class="row">
     <div class="col-xs-12 col-sm-12 col-md-12">

       <div class="form-group">

         <strong>Username:</strong>

         <?php echo Form::text('username', null, array('placeholder' => 'Username','class' => 'form-control')); ?>


       </div>

     </div>
     
     <div class="col-xs-12 col-sm-12 col-md-12">

       <div class="form-group">

         <strong>Name:</strong>

         <?php echo Form::text('name', null, array('placeholder' => 'Name','class' => 'form-control')); ?>


       </div>

     </div>
     
     <div class="col-xs-12 col-sm-12 col-md-12">

       <div class="form-group">

         <strong>Email:</strong>

         <?php echo Form::text('email', null, array('placeholder' => 'Email','class' => 'form-control')); ?>


       </div>

     </div>
     
     <div class="col-xs-12 col-sm-12 col-md-12">

       <div class="form-group">

         <strong>Password:</strong>

         <?php echo Form::password('password', array('placeholder' => 'Password','class' => 'form-control')); ?>


       </div>

     </div>
     
     <div class="col-xs-12 col-sm-12 col-md-12">

       <div class="form-group">

         <strong>Confirm Password:</strong>

         <?php echo Form::password('confirm-password', array('placeholder' => 'Confirm Password','class' => 'form-control')); ?>


       </div>

     </div>
     <?php
     $isCurrentUser = Auth::user()->id == $user->id;
     $isHide = '';
     if ($isCurrentUser) {
       $isHide = 'hidden';
     }
     ?>

     <div class="col-xs-12 col-sm-12 col-md-12 <?php echo e($isHide); ?> ">

       <div class="form-group">

         <strong>Hak Akses:</strong>

         <?php echo Form::select('roles', $roles, $userRole, array('class' => 'form-control')); ?>


       </div>

     </div>

     <div class="col-xs-12 col-sm-12 col-md-12 <?php echo e($isHide); ?>">

       <div class="form-group">

         <strong>Status:</strong>

         <?php echo Form::select('status', Config::get('enums.status_user'), $user->status, array('class' => "form-control")); ?>




       </div>

     </div>
     
     <div class="col-xs-12 col-sm-12 col-md-12 text-center">

       <button type="submit" class="btn btn-primary">Submit</button>

     </div>
     
   </div>

   <?php echo Form::close(); ?>


 </div>
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template_inspi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>