<?php $__env->startSection('page-title', 'Jenis Perkara'); ?>
<?php $__env->startSection('custom_css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-sm-12">
    <div class="ibox float-e-margins">
      <div class="ibox-title">
        <div class="ibox-tools">
          <button class="btn btn-success" onclick="location.href='<?php echo e(route('jenis_perkara.create')); ?>'">Tambah Jenis Perkara</button>
        </div>
      </div>
      <div class="ibox-content">
        <div class="table-responsive">
          <table class="table" id="table-jenis">
            <thead>
              <tr>
                <th>No</th>
                <th>Nama Perkara</th>
                <th width="1%">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $no=1; ?>
              <?php $__currentLoopData = $jenis_perkara; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $jenis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
                <td><?php echo e($no++); ?></td>
                <td><?php echo e($jenis->nama); ?></td>
                <td style="white-space: nowrap">
                  <a href="<?php echo e(route('jenis_perkara.edit', $jenis->id)); ?>" class="btn btn-primary">Edit</a>
                  <a onclick="deleteJenis('<?php echo e($jenis->id); ?>')" class="btn btn-danger">Delete</a>
                </td>
              </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
          </table>
        </div>
      </div>
    </div>
  </div> <!-- end col -->
</div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<script>
  let $tableJenis = $("#table-jenis").DataTable();


  function deleteJenis(id) {
    swal({
      icon : 'warning',
      title : 'Hapus Jenis Perkara ? ',
      text : 'Yakin Hapus Jenis Perkara ? ',
      buttons : {
        'Batal' : {
          className : 'btn btn-info'
        },
        'Hapus' : {
          className : 'btn btn-danger'

        }
      },
      closeOnClickOutside : false,
    })
    .then(btn => {
      if (btn == 'Hapus') {
       axios.post('<?php echo e(route('jenis_perkara.index')); ?>'+ '/' + id, {

          _method : 'DELETE',
          _token : '<?php echo e(csrf_token()); ?>',

       })
       .then(resp => {
        location.href = '<?php echo e(route('jenis_perkara.index')); ?>';
       })
      }

    });
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template_inspi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>