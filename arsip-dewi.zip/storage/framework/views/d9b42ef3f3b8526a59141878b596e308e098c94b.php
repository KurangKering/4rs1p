<?php $__env->startSection('page-title', 'Daftar Berkas Perkara'); ?>
<?php $__env->startSection('custom_css'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="row">
  <div class="col-sm-12">
    <div class="ibox float-e-margins">
      <div class="ibox-title">
        <div class="ibox-tools">
          <!-- <button class="btn btn-success" onclick="location.href='<?php echo e(route('perkara.create')); ?>'">Tambah Perkara</button> -->
        </div>
      </div>
      <div class="ibox-content">
        <div class="table-responsive">
          <table class="table" id="table-perkara">
            <thead>
              <tr>
                <th>No </th>
                <th>No Perkara</th>
                <th>Jenis Perkara</th>
                <th>Nama Berkas</th>
                <th width="1%">Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $no = 1; ?>
              <?php $__currentLoopData = $berkases; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $berkas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tr>
               <td><?php echo e($no++); ?></td>
               <td><?php echo e($berkas->perkara->no_perkara); ?></td>
               <td><?php echo e($berkas->perkara->jenis_perkara->nama); ?></td>
               <td><?php echo e($berkas->nama); ?></td>
               <td style="white-space: nowrap">

                <a onclick="bacaBerkas('<?php echo e($berkas->id); ?>')" class="btn btn-info">Read</a>

              </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>
</div> <!-- end col -->
</div>

<form id="form-form"></form>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom_js'); ?>
<script>
  let $tablePerkara = $("#table-perkara").DataTable();
  function bacaBerkas(id) {
    var   newForm = jQuery('<form>', {
      'action' : '<?php echo e(route('berkas_perkara.read')); ?>',
      'target' : '_blank',
      'method' : 'post'
    }).append(jQuery('<input>', {
      'name' : 'id',
      'value' : id,
      'type' : 'hidden'
    }))
    .append(jQuery('<input>', {
      'name' : '_token',
      'value' : '<?php echo e(csrf_token()); ?>',
      'type' : 'hidden'
    }))
    newForm.appendTo($('#form-form'));
    newForm.submit();
  }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template_inspi', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>