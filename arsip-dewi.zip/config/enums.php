<?php 
return [
	'jenis_kelamin' => [
		'LK' => "Laki-Laki",
		'P' => "Perempuan"
	],
	'status_user' => [
		'1' => 'inactive',
		'2' => 'active'
	]
];